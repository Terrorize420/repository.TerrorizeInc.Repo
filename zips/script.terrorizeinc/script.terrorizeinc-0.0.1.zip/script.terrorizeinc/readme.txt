Terrorize Inc Test Script
